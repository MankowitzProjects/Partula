#ifndef SENSORCONTROLLER_H_INCLUDED
#define SENSORCONTROLLER_H_INCLUDED

#include "Sensor.h"

class SensorController
{
public:
    SensorController(void);

    void init(void);
    void fin(void);

private:


    /**< Stores all the sensor information, the init() function
         will be called when the table is created */
    Sensor sensorTable[NUM_SENSOR_SLOTS];

    void regHandlers(void);
    void clrHandlers(void);

    int lstRptSensorID;     /**< The last reported sensor index */


    void setupSensors(void);

    inline void setSensorValue(const int index, const int value);
    inline int  getSensorValue(const int index);

    inline void        setSensorType(const int index, const TYPE_SENSOR type);
    inline TYPE_SENSOR getSensorType(const int index);

};

/** \brief Default constructor
 *
 * \param void
 *
 */
SensorController::SensorController(void)
{
    ;
}

/** \brief Set up the information of the sensors installed
 *
 * \param void
 * \return void
 *
 */
void SensorController::setupSensors(void)
{
    // IR sensor LEFT
    sensorTable[INDEX_SENSOR_IR_LEFT].init (INDEX_SENSOR_IR_LEFT, TYPE_SENSOR_IR, POSITION_LEFT);
    // IR sensor RIGHT
    sensorTable[INDEX_SENSOR_IR_RIGHT].init(INDEX_SENSOR_IR_RIGHT, TYPE_SENSOR_IR, POSITION_RIGHT);
}

/** \brief Initialize the sensor controller
 *
 * \param void
 * \return void
 *
 */
void SensorController::init(void)
{
    prt_debug("SensorController::init\n");

    regHandlers();

    setupSensors();

    prt_debug("SensorController::init done!\n");
}

/** \brief Finalize the class
 *
 * \param void
 * \return void
 *
 */
void SensorController::fin(void)
{
    clrHandlers();
}

/** \brief Set the value for a sensor regarding to it's index number
 *
 * \param index const int
 * \param value const int
 * \return void
 *
 */
inline void SensorController::setSensorValue(const int index, const int value)
{
    sensorTable[index].setValue(value);
    lstRptSensorID = index;
}

/** \brief Get the sensor value by given sensor index
 *
 * \param index const int   The sensor index
 * \return int
 *
 */
inline int SensorController::getSensorValue(const int index)
{
    return sensorTable[index].getValue();
}

inline void SensorController::setSensorType(const int index, const TYPE_SENSOR type)
{
    sensorTable[index].setType(type);
}

inline TYPE_SENSOR SensorController::getSensorType(const int index)
{
    return sensorTable[index].getType();
}

void SensorController::regHandlers(void)
{

}

void SensorController::clrHandlers(void)
{

}

#endif // SENSORCONTROLLER_H_INCLUDED
