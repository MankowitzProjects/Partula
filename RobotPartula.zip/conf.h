#ifndef CONF_H_INCLUDED
#define CONF_H_INCLUDED

#include <stdio.h>

#if defined(_MSC_VER) && (_MSC_VER >= 1200 )
    #include "./include/phidget21.h"
#else
   #include <phidget21.h>
#endif

#include "debug_tools.h"

//*********************************** NULL ***********************************
#ifndef NULL
#define NULL 0
#endif

#define VALUE_NULL      NULL
#define STATE_NULL      NULL
#define POINTER_NULL    NULL


//*********************************** LEGO ***********************************
#define NUM_SENSOR_SLOTS 8

//*********************************** INDEX **********************************
#define INDEX_SENSOR_IR_LEFT    0
#define INDEX_SENSOR_IR_RIGHT   1

//*********************************** TYPE ***********************************
const char *g_sensorTypeDis[] = {
/* 0x00 */  "null",
/* 0x01 */  "IR",
/* 0x02 */  "whisker",
/* 0x03 */  "switch"
};

typedef enum
{
    TYPE_SENSOR_NULL    = 0x00,
    TYPE_SENSOR_IR      = 0x01,
    TYPE_SENSOR_WHISKER = 0x02,
    TYPE_SENSOR_SWITCH  = 0x03

} TYPE_SENSOR;


static inline const char *GetSensorTypeChar(TYPE_SENSOR type)
{
    return g_sensorTypeDis[type];
}

//********************************* POSITION *********************************
const char *g_position[] =
{
/* 0x00 */  "null",
/* 0x01 */  "front",
/* 0x02 */  "back",
/* 0x03 */  "left",
/* 0x04 */  "right"
};

typedef enum
{
    POSITION_NULL   = 0x00,
    POSITION_FRONT  = 0x01,
    POSITOIN_BACK   = 0x02,
    POSITION_LEFT   = 0x03,
    POSITION_RIGHT  = 0x04

} POSITION;

static inline const char *GetSensorPositionChar(POSITION position)
{
     return g_position[position];
}
#define INDEX_MOTOR_LEFT    0
#define INDEX_MOTOR_RIGHT   1

#endif // CONF_H_INCLUDED
