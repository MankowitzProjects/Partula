#ifndef ROBOT_H_INCLUDED
#define ROBOT_H_INCLUDED

#include "MotorController.h"
#include "SensorController.h"


class Robot
{
public:
    void init(void);
    void run(void);
    void fin(void);

    Robot(void);
    ~Robot(void);
private:

    MotorController  motorCtrl;
    SensorController sensorCtrl;

    bool isInit;
};

Robot::Robot(void)
{
    prt_debug("Creating robot\n");
    isInit = false;
}

Robot::~Robot(void)
{
    fin();
}

void Robot::run(void)
{
    motorCtrl.setAcceleration(50.0);
    motorCtrl.setVelocity(80.0);

    motorCtrl.goForwards();

    wait(1000);

    motorCtrl.turnLeft();

    wait(1000);

    motorCtrl.stop();

    motorCtrl.motorLeft.spin();

    wait(1000);

    motorCtrl.turnRight();

    wait(1000);

    motorCtrl.goBackwards();

    wait(1000);
}

void Robot::init(void)
{
    if (isInit)
    {
        return;
    }

    motorCtrl.init();
    sensorCtrl.init();

    isInit = true;
}

void Robot::fin(void)
{
    motorCtrl.fin();
    sensorCtrl.fin();
}

#endif // ROBOT_H_INCLUDED
